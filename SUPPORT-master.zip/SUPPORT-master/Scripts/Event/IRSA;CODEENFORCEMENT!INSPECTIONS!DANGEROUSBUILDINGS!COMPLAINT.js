//IRSA;CODEENFORCEMENT!INSPECTIONS!DANGEROUSBUILDINGS!COMPLAINT

// Script #4 - Dangerous Buildings Complaint - Inspection Report

var inspector = getInspector(inspType);
var supervisor = lookup("EMSE:DNG_Inspector_Supervisor_Lookup", inspector);
var spvrEmail = getUserEmail(supervisor);
var recordId = capId.getCustomID();

/* logDebug("inspector: " + inspector);
logDebug("supervisor: " + supervisor);
logDebug("spvrEmail: " + spvrEmail);
logDebug("recordId: " + recordId); */

var inspResultObj = aa.inspection.getInspections(capId);
if (inspResultObj.getSuccess()){
	var inspList = inspResultObj.getOutput();
	for(var i in inspList){   
		if (inspList[i].getInspectionType() == inspType){
			var inspID = inspList[i].getIdNumber(); 	
			logDebug("inspID: " + inspID);
		}
	}
}

// get checklist items
var inspResultObj = aa.inspection.getInspections(capId);
var ins = inspResultObj.getOutput();
var dbChecklist = new Array();
var ieChecklist = new Array();
for (i in ins){
	if(ins[i].getIdNumber() == inspID){
		var inspModel = ins[i].getInspection();
		var gs = inspModel.getGuideSheets();
		if( gs != null){	
			gsArray = gs.toArray();
			for (var n in gsArray){
				a = gsArray[n];				
				var gsItems = gsArray[n].getItems().toArray()

				for(i in gsItems){
					var gsType = gsItems[i].getGuideType();
					
					if (gsType == "DANGEROUS BUILDINGS"){
						var itemText = gsItems[i].getGuideItemText();
						var itemStatus = gsItems[i].getGuideItemStatus();
						var itemComment = gsItems[i].getGuideItemComment();
						dbChecklist.push(itemText + ": " + itemStatus + "\r\n");
						//logDebug(itemText + ": " + itemStatus);
					}
					
					if (gsType == "INSURANCE ESCROW"){
						var itemText = gsItems[i].getGuideItemText();
						var itemStatus = gsItems[i].getGuideItemStatus();
						var itemComment = gsItems[i].getGuideItemComment();
						ieChecklist.push(itemText + ": " + itemStatus + "\r\n");
						//logDebug(itemText + ": " + itemStatus);
					}
					
				}
			}
		}
	}
}

var dbString = dbChecklist.join("<br>");
var ieString = ieChecklist.join("<br>");

var reply = "noreply@accela.com";
var emailParameters = aa.util.newHashtable();
addParameter(emailParameters, "$$recordId$$", recordId);
addParameter(emailParameters, "$$inspType$$", inspType);
addParameter(emailParameters, "$$inspector$$", inspector);
addParameter(emailParameters, "$$dbChecklist$$", dbString);
addParameter(emailParameters, "$$ieChecklist$$", ieString);
sendNotification(reply, spvrEmail, "", "CODEENF_INSPECTION_REPORT", emailParameters, null);