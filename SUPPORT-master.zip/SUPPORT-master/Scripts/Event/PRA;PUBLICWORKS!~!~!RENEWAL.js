//PRA;PUBLICWORKS!~!~!RENEWAL
//PRA:PUBLICWORKS/*/*/RENEWAL (Script Code Name)
//PRA:PublicWorks/*/*/Renewal (Standard Choice Name)
//Updates license record when business license renewal fee is paid
//aa.runScriptInNewTransaction("PaymentReceiveAfter4Renew");