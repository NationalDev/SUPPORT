//*********************************************************************************************************/
//	WTUA;LICENSES!~!~!APPLICATION.js																	       /
//																			Iman Sallam @ City of Detroit  /
//		Deploy with the script code and script title below (all caps)									   /
//																								           /
//					WTUA:LICENSES/*/*/APPLICATION														   / 							
//																										   /
//*********************************************************************************************************/





   showDebug = true;
   showMessage= true;





if (balanceDue <= "75" ) {
	balanceDue = "75";
}