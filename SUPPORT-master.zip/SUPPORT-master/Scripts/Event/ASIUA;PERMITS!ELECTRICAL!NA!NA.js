/**
 * To calculate and assess permit fee based on the fixtures or equipment types.
 * 
 * Event Name:- Application Specific Info Update After
 * Event Description:- The after event for when a user updates application specific information
 * MasterScript:- ApplicationSpecificInfoUpdateAfterV3.0.js
 * Record Type:- ASIUA;PERMITS!ELECTRICAL!NA!NA.js
 * 
 * 08/04/2016 Abhishek Jain, FutureNet Group, Inc.
 * 
 * Updated By:- 08/05/2016	Charles Redmond, FutureNet Group, Inc.
 * 
 * TODO: NEED TO add appMatch("") strings to specify which food service record types will trigger this script
 * 
 * Formatted By:- Chaitanya Tanna, City of Detroit
 */

//---CHANGE PARAMETERS BELOW TO MATCH RECORD TYPE CONFIG-----------------------------------------//
var feeSched = "PMTELE_F";
var baseFee = "ELE0000";
var cList = ELEFIX;
//var sharedDropDown = "ELE_FIX_TYPE";   //Name of Shared Drop Down as it appears in Standard Choices
//---END PARAMETERS-------------------------------------------------------------------------------//

copyParcelGisObjects();

var feeScheduleItemArr = aa.finance.getFeeItemList(null,feeSched,null).getOutput();
var subTotalItemArr = new Array(feeScheduleItemArr.length);
var baseFeeApply = "false";
var partA_Item = "X";


if (typeof(cList) == "object") {
    
    for (row in cList) {
        var fixTypeFee = cList[row]["Electrical Equipment"].toString();
      
      	if (baseFeeApply == "false") {
        	partA_Item = fixTypeFee.charAt(0);
           
        	if (partA_Item == "A") {
        		baseFeeApply = "true";
            } 

        }
      

      	for (i=0;i<feeScheduleItemArr.length;i++) {
            
			if (row == 0) { 
            	subTotalItemArr[i]=0;
            }
            
            if (fixTypeFee == feeScheduleItemArr[i].getFeeDes().toString()) {              
                subTotalItemArr[i] += parseInt(cList[row]["Quantity"]);
            }
        }
    
      
    }
 
	if (baseFeeApply == "true") { 
    	subTotalItemArr[0]=1;
    }
            
 
    for (f=0;f<feeScheduleItemArr.length;f++) {
        
        if (subTotalItemArr[f] > 0) {
            
            updateFee(feeScheduleItemArr[f].getFeeCod().toString(),feeSched,"FINAL",parseInt(subTotalItemArr[f]),"N");
        }
    }
}