// MSA:CodeEnforcement/Inspections/DangerousBuildings/Complaint

/*(logDebug("CalendarID: " + CalendarID);
logDebug("MeetingID: " + MeetingID);

var mtgInfo = aa.meeting.getMeetingByMeetingID(CalendarID ,MeetingID );
var meetingDate = mtgInfo.output.getStartDate();
logDebug("The Meeting date is:" + meetingDate); */

// Script # 6 - Dangerous Buildings City Council
var mtgInfo = aa.meeting.getMeetingByMeetingID(CalendarID, MeetingID).getOutput();
var meetingDate = mtgInfo.getStartDate();
// format date
var sDate = aa.date.parseDate(meetingDate);
var schedDate = convertDate(sDate);
var dd = schedDate.getDate();
var mm = schedDate.getMonth()+1; //January is 0!
var yyyy = schedDate.getFullYear();
var meetingScheduledDate = mm + "/" + dd + "/" + yyyy;

var meetingTime = mtgInfo.getStartTime();
var meetingType = mtgInfo.getMeetingType();
var meetingLocation = mtgInfo.getMeetingLocation();
var meetingStatus=mtgInfo.getMeetingStatus();
var meetingBody=mtgInfo.getMeetingBody();

var calendarResult = aa.calendar.getCalendar(CalendarID);
if (calendarResult.getSuccess()){
	calendarModel = calendarResult.getOutput();
	var calName = calendarModel.getCalendarName();
}

if(meetingType=="CITY COUNCIL HEARING" && meetingStatus=="Scheduled" && calName=="City Council Hearing" && meetingBody=="City Council")
{
	var replyAdd = "noreply@accela.com";
	var template = "CODEENF_CITYCOUNCIL_HEARING";
	var contArr = getContactArray(capId); //getting all the contacts to send to
	for (x in contArr){
		if (matches(contArr[x]["contactType"], "Property Owner", "Interested Party")) {
			var emailAdd = contArr[x]["email"];
			var emailParameters=aa.util.newHashtable();
			addParameter(emailParameters,"$$location$$",meetingLocation);
			addParameter(emailParameters,"$$scheduledDate$$",meetingScheduledDate);
			addParameter(emailParameters,"$$scheduledTime$$",meetingTime);
			sendNotification(replyAdd,emailAdd,"",template,emailParameters,null);
		}
	}
}

//Script #5 - Dangerous Buildings Office Hearing
var calendarResult = aa.calendar.getCalendar(CalendarID);
if (calendarResult.getSuccess()){
		calendarModel = calendarResult.getOutput();
		calName = calendarModel.getCalendarName();
}

var mtgInfo = aa.meeting.getMeetingByMeetingID(CalendarID, MeetingID).getOutput();
var meetingDate = mtgInfo.getStartDate();
// format Date
var sDate = aa.date.parseDate(meetingDate);
var schedDate = convertDate(sDate);
var dd = schedDate.getDate();
var mm = schedDate.getMonth()+1; //January is 0!
var yyyy = schedDate.getFullYear();
var meetingScheduledDate = mm + "/" + dd + "/" + yyyy;
//logDebug(mm + "/" + dd + "/" + yyyy);

var meetingType = mtgInfo.getMeetingType();
var meetingTime = mtgInfo.getStartTime();
var meetingLocation = mtgInfo.getMeetingLocation();
var meetingStatus = mtgInfo.getMeetingStatus();
var meetingBody = mtgInfo.getMeetingBody();

if(calName = "Office Hearing" && meetingType == "OFFICE HEARING" && meetingBody == "DB Office Hearing Panel" && meetingStatus == "Scheduled") {
	var replyAdd = "noreply@accela.com";
	var template = "CODEENF_OFFICE_HEARING";
	var emailAdd = null;
	var contArr = getContactArray(capId);
	for (x in contArr){
		if (matches(contArr[x]["contactType"], "Property Owner", "Interested Party")) {
			emailAdd = contArr[x]["email"];
			var emailParameters = aa.util.newHashtable();
			addParameter(emailParameters,"$$location$$",meetingLocation);
			addParameter(emailParameters,"$$scheduledDate$$",meetingScheduledDate);
			addParameter(emailParameters,"$$scheduledTime$$",meetingTime);
			addParameter(emailParameters,"$$recordId$$", capId);
			sendNotification(replyAdd,emailAdd,"",template,emailParameters,null);
		}
	}
}	
