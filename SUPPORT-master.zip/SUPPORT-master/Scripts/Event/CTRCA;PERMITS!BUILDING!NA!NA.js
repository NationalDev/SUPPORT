/*
* To calculate and assess permit fee based on the fixtures or equipment types.
* Event Name: ConvertToRealCAPAfter
* Event Description: Citizen Access - The after event for converting a partial record ID to a real record ID.
* Master Script: ConvertToRealCapAfter
*
* Record Type: Permits/Building/NA/NA (Building Permit)
* 05/11/16 – Satish Patel, FutureNet Group, Inc.
*/