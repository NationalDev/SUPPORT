//////*********************************************************************************************************
//////	PRA;LICENSES!~!~!APPLICATION.js																	   
//////																			Iman Sallam @ City of Detroit  
//////		Deploy with the script code and script title below (all caps)									   
//////																								           
//////					PRA:LICENSES/*/*/APPLICATION	
////// 							
//////			October 19th, 2017			Revision 2.0
//////*********************************************************************************************************
//
//
//
//
try{
	
	var showDebug = true;
	var showMessage = true;


	if (isTaskStatus("License Issuance","Approved") && balanceDue <= 0) {
			
			
//				newLic = null;
//				newLicId = null;
//				newLicIdString = null;
//				parent = getParent(capId);
			 
//				logDebug(" newLicId = " + newLicId +" parent = " + parentCapId);
		
				newLicIdString = capId.getCustomID();
	        
				      
				    
				logDebug("newLicIdString = " + newLicIdString + "  capId = "  + capId + " Parent =" + parentCapId); 
				        
				        
				        
//				        
////	      //**************************************************************************************    
//				        tmpNewDate = new Date();
//	    
//					    /**
//					     * Check Condition for Mechinical!Contractor Registration
//					     */
//					    if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "Contractor Registration") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					            thisYear += 3;
//					            newExpDate = "08/31/" + thisYear.toString();
//					        if (newLicId) {
//					            thisLic = new licenseObject(newLicIdString,newLicId);
//					            thisLic.setExpiration(dateAdd(newExpDate,0));
//					            thisLic.setStatus("Active");
//					            }
//					    }
//					    /**
//					     * Check Condition for Electrical!Apprentice
//					     */
//					    if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Apprentice") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					        thisMonth = tmpNewDate.getMonth();
//					        	if (thisMonth > 7) {
//					            thisYear += 1;     //thisYear = thisYear + 1;
//					        }
//					        newExpDate = "08/31/" + thisYear.toString();
//					        	if (newLicId) {
//					        	thisLic = new licenseObject(newLicIdString,newLicId);
//					        	thisLic.setExpiration(dateAdd(newExpDate,0));
//					        	thisLic.setStatus("Active");
//					        }
//					    }
//					    /**
//					     * Check Condition for Plumbing!Contractor Registration
//					     */
//					    if (appTypeArray[1] == "Plumbing" && appTypeArray[2] == "Contractor Registration") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					            thisYear += 3;
//					            newExpDate = "04/30/" + thisYear.toString();
//					            if (newLicId) {
//					            thisLic = new licenseObject(newLicIdString,newLicId);
//					            thisLic.setExpiration(dateAdd(newExpDate,0));
//					            thisLic.setStatus("Active");
//					        }
//					    }
//					    /**
//					     * Check condition for Boiler!Contractor Registration
//					     */
//					    if (appTypeArray[1] == "Boiler" && appTypeArray[2] == "ContractorRegistration") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					            thisYear += 3;
//					            newExpDate = "12/31/" + thisYear.toString();
//					            if (newLicId) {
//					            thisLic = new licenseObject(newLicIdString,newLicId);
//					            thisLic.setExpiration(dateAdd(newExpDate,0));
//					            thisLic.setStatus("Active");
//					            }
//					    }
//					    /**
//					     * Check Condition for Mechanical!Occupational
//					     */ 
//					    if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "Occupational") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					        monthsToInitialExpire = 12;
//					        tmpNewDate = dateAddMonths(null, monthsToInitialExpire);
//					        	if (newLicId) {
//					        	thisLic = new licenseObject(newLicIdString,newLicId);
//					        	thisLic.setExpiration(dateAdd(tmpNewDate,0));
//					        	thisLic.setStatus("Active");
//					        }
//					    }
//					    /**
//					   	 * Check Condition for Mechanical!RefrigJourneyman
//					   	 */ 
//					    if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "RefrigJourneyman") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					        monthsToInitialExpire = 12;
//					        tmpNewDate = dateAddMonths(null, monthsToInitialExpire);
//					        	if (newLicId) {
//					        	thisLic = new licenseObject(newLicIdString,newLicId);
//					        	thisLic.setExpiration(dateAdd(tmpNewDate,0));
//					        	thisLic.setStatus("Active");
//					        }
//					    }
//					      /**
//					     * Check Condition Building!ContractorRegistration
//					     */ 
//					    if (appTypeArray[1] == "Building" && appTypeArray[2] == "ContractorRegistration") {
//					        thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					        newExpDate = "12/31/" + thisYear.toString();
//					       		if (newLicId) {
//					       		thisLic = new licenseObject(newLicIdString,newLicId);
//					       		thisLic.setExpiration(dateAdd(newExpDate,0));
//					       		thisLic.setStatus("Active");
//					       	}
//					    
//					    } 
//					    else if (appTypeArray[1] == "Building" && appTypeArray[2] == "Sign-AwingContractor") {
//						    thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//						    newExpDate = "12/31/" + thisYear.toString();
//						    	if (newLicId) {
//						    	thisLic = new licenseObject(newLicIdString,newLicId);
//						    	thisLic.setExpiration(dateAdd(newExpDate,0));
//						    	thisLic.setStatus("Active");
//						    }
//					    } 
//					    else if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Contractor") {
//					    	thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					    	newExpDate = "12/31/" + thisYear.toString();
//					    		if (newLicId) {
//					    		thisLic = new licenseObject(newLicIdString,newLicId);
//					    		thisLic.setExpiration(dateAdd(newExpDate,0));
//					    		thisLic.setStatus("Active");
//					    	}
//					     } 
//					    else if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "ContractorRegistration") {
//					    	 thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					    	 newExpDate = "12/31/" + thisYear.toString();
//					    	 	if (newLicId) {
//					    		 thisLic = new licenseObject(newLicIdString,newLicId);
//					    		 thisLic.setExpiration(dateAdd(newExpDate,0));
//					    		 thisLic.setStatus("Active");
//					    	 }
//						 } 
//					    else if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Masters-Journeyman") {
//							 thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//							 newExpDate = "12/31/" + thisYear.toString();
//							 	if (newLicId) {
//								 thisLic = new licenseObject(newLicIdString,newLicId);
//								 thisLic.setExpiration(dateAdd(newExpDate,0));
//								 thisLic.setStatus("Active");
//							 }	      	
//						 } 
//					    else if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "Elevator") {
//							 thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//							 newExpDate = "12/31/" + thisYear.toString();
//							 	if (newLicId) {
//								 thisLic = new licenseObject(newLicIdString,newLicId);
//								 thisLic.setExpiration(dateAdd(newExpDate,0));
//								 thisLic.setStatus("Active");
//							 }	      	
//						 } 
//	    
//					    else if (appTypeArray[1] == "Building" && appTypeArray[2] == "WreckingContractor") {
//					    	thisYear = parseInt(tmpNewDate.getYear().toString()) + 1900;
//					    	newExpDate = "12/31/" + thisYear.toString();
//					    		if (newLicId) {
//					    		 thisLic = new licenseObject(newLicIdString,newLicId);
//					    		 thisLic.setExpiration(dateAdd(newExpDate,0));
//					    		 thisLic.setStatus("Active");
//			 }	      	
//					    } 
//					    
//	}  
//					    
//	
//							    	             
									
//		//  
//		////************************************ REPORT SELECTION **********************************
//		//
//		////function runReport4EmailOrPrint(itemCap,reportName,conObj,rParams,eParams,emailTemplate,module) {
//		////If email address available for contact type then email the report, otherwise pop up the report on the screen  
//		//  function generateReport(itemCap, reportName, module, parameters)
//		////*********************************** STATIONARY ENGINEER  
//										  
										      		        
					        
												LICENSETYPE = "";
												LICENSETYPE = getAppSpecific("License Type",capId);
										  
										  	    logDebug("License Type: " + lookup("LIC LICENSED PROFESSIONALS",LICENSETYPE) + "  ID = " + newLicIdString );
										  	    
										  	  licIDString = null;
										  	
										  	    if (LICENSETYPE == "1st Class Station Eng") {
										  	     
										  		var rParams = aa.util.newHashMap();
										  	     	addParameter(rParams,"RECORD_ID",newLicIdString );
										  			addParameter(rParams,"TASK","License Issuance");
										  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
										  			addParameter(rParams,"PRIMARY_","Y");
										  			
										  			logDebug("Parameters1: " + rParams);
										
										  			generateReport(capId , "12 Stationary Engineer" , "Licenses", rParams);    
//										  			
										 
										  			}
										  	
										  	else if (LICENSETYPE == "2nd Class Station Eng")  {
											     
												var rParams = aa.util.newHashMap();
												addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters2: " + rParams);
									
									  			generateReport(capId , "12 Stationary Engineer" , "Licenses", rParams);    
									  			//runReport4EmailOrPrint(capId , "12 Stationary Engineer" ,null,rParams,null,null,"Licenses");
													} 
										
										  	else if (LICENSETYPE == "3rd Class Station Eng") {
										    
										  		var rParams = aa.util.newHashMap();
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters3: " + rParams);
									
									  			generateReport(capId , "12 Stationary Engineer" , "Licenses", rParams);    
										
													} 
										 
										////*********************************** BOILER 
										
										  	else if (LICENSETYPE == "Boiler Op HP") {
										  	
										  		
										  		var rParams = aa.util.newHashMap();
													
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters4: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										 
										  	else if (LICENSETYPE == "Boiler Op LP") {
										  	
												
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters5: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										  	
										  	else if (LICENSETYPE == "1st Class Refrig Op") {
										  	
												
										  		var rParams = aa.util.newHashMap();
										  		
										  		addParameter(rParams,"RECORD_ID", newLicIdString);
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters6: " + rParams);
									
									  			generateReport(capId, "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
									  			
									  			
									  			
										  			}
										
										  	else if (LICENSETYPE == "2nd Class Refrig Op") {
										  	
												
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters7: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										  	
										  	else if (LICENSETYPE == "3rd Class Refrig Op") {
										  	
												
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters8: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										//*********************************** ALL OTHERS *************************************************************
										  	
										  	else{		
										  		
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters9: " + rParams);
									
									  			generateReport(capId , "License" , "Licenses", rParams);    
									
									  			
												
										  			}
										  	    
										  	    
	
	}				  	
										 }catch (err) {
												logDebug("A JavaScript Error occured: " + err.message + " In Line " + err.lineNumber);
											}
										// end user code
											aa.env.setValue("ScriptReturnCode", "1"); 	aa.env.setValue("ScriptReturnMessage", debug)

