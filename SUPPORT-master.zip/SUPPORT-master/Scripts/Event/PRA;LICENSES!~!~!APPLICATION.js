//////*********************************************************************************************************
//////	PRA;LICENSES!~!~!APPLICATION.js																	   
//////																			Iman Sallam @ City of Detroit  
//////		Deploy with the script code and script title below (all caps)									   
//////																								           
//////					PRA:LICENSES/*/*/APPLICATION	
////// 							
//////			October 19th, 2017			Revision 2.0
//////			October 23rd, 2017			Revision 3.0
//////			October 25rd, 2017			Revision 3.1				Added more Reports
//////*********************************************************************************************************
//
//
//
//
try{
	
	var showDebug = true;
	var showMessage = true;


	if (isTaskStatus("License Issuance","Approved") && balanceDue <= 0) {
			
			
				newLic = null;
				newLicId = null;
				newLicIdString = null;
				parent = getParent(capId);
			 
				logDebug(" newLicId = " + newLicId +" parent = " + parentCapId);
		
				newLicIdString = capId.getCustomID();
	        
				      
				    
				logDebug("newLicIdString = " + newLicIdString + "  capId = "  + capId + " Parent =" + parentCapId); 
				        

//		************************************ REPORT SELECTION **********************************

//						 generateReport(itemCap, reportName, module, parameters)
//				
//	********************************************************************************************	
				
				
				
//		*********************************** STATIONARY ENGINEER  *****************************************************
										  
										      		        
					        
												LICENSETYPE = "";
												LICENSETYPE = getAppSpecific("License Type",capId);
										  
										  	    logDebug("License Type: " + lookup("LIC LICENSED PROFESSIONALS",LICENSETYPE) + "  ID = " + newLicIdString );
										  	    
										  	    licIDString = null;
										  	  
						  	if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "Occupational") {			
						  		
									  	    if (LICENSETYPE == "1st Class Station Eng") {
									  	     
									  		var rParams = aa.util.newHashMap();
									  	     	addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters1: " + rParams);
									
									  			generateReport(capId , "12 Stationary Engineer" , "Licenses", rParams);    
										  			}
										  	
										  	else if (LICENSETYPE == "2nd Class Station Eng")  {
											     
												var rParams = aa.util.newHashMap();
												addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters2: " + rParams);
									
									  			generateReport(capId , "12 Stationary Engineer" , "Licenses", rParams);    
													} 
										
										  	else if (LICENSETYPE == "3rd Class Station Eng") {
										    
										  		var rParams = aa.util.newHashMap();
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters3: " + rParams);
									
									  			generateReport(capId , "12 Stationary Engineer" , "Licenses", rParams);    
													} 
										 
//********************************************************************** BOILER *********************************************************
										
										  	else if (LICENSETYPE == "Boiler Op HP") {
										  	
										  		var rParams = aa.util.newHashMap();
													
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters4: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										 
										  	else if (LICENSETYPE == "Boiler Op LP") {
										
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters5: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										  	
										  	else if (LICENSETYPE == "1st Class Refrig Op") {
										  	
												
										  		var rParams = aa.util.newHashMap();
										  		
										  		addParameter(rParams,"RECORD_ID", newLicIdString);
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters6: " + rParams);
									
									  			generateReport(capId, "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
									  					  			
										  			}
										
										  	else if (LICENSETYPE == "2nd Class Refrig Op") {
										  	
												
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters7: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
										  	
										  	else if (LICENSETYPE == "3rd Class Refrig Op") {
										  	
												
										  		var rParams = aa.util.newHashMap();
												
										  		addParameter(rParams,"RECORD_ID",newLicIdString );
									  			addParameter(rParams,"TASK","License Issuance");
									  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
									  			addParameter(rParams,"PRIMARY_","Y");
									  			
									  			logDebug("Parameters8: " + rParams);
									
									  			generateReport(capId , "13 Mechanical Occupational Licenses" , "Licenses", rParams);    
										
										  			}
						
						  	}
						  	
//*********************************** Building Contractor Registration *************************************************************
										  	    
						    if (appTypeArray[1] == "Building" && appTypeArray[2] == "ContractorRegistration") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters9: " + rParams);
					
					  			generateReport(capId , "02 Building Contractor Req" , "Licenses", rParams);    
						  	
						    	}			
						    
//*********************************** Boiler Contractor Registration *************************************************************
					  	    
						    if (appTypeArray[1] == "Boiler" && appTypeArray[2] == "ContractorRegistration") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters10: " + rParams);
					
					  			generateReport(capId , "01 Boiler Contractor Reg" , "Licenses", rParams);    
						  	
						    	}			
						    
//*********************************** Electrical Apprentice Registration *************************************************************
					  	    
						    if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Apprentice") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters11: " + rParams);
					
					  			generateReport(capId , "08 Electrical Apprentice Reg" , "Licenses", rParams);    
						  	
						    	}			
						    
//*********************************** Electrical Contractor Registrations *************************************************************
					  	    
						    if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "ContractorRegistration") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters12: " + rParams);
					
					  			generateReport(capId , "07 Electrical Contractor Registration" , "Licenses", rParams);    
						  	
						    	}			
						    						    
						    
//*********************************** Electrical Contractor License *************************************************************
					  	    
						    if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Contractor") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters13: " + rParams);
					
					  			generateReport(capId , "09 Electrical Contractor License" , "Licenses", rParams);    
						  	
						    	}			
						    
						    
//*********************************** Plumbing Contractor Registration *************************************************************
					  	    
						    if (appTypeArray[1] == "Plumbing" && appTypeArray[2] == "Contractor Registration") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters14: " + rParams);
					
					  			generateReport(capId , "06 Plumbing Contractor Reg" , "Licenses", rParams);    
						  	
						    	}	
						    
						    
//***********************************  Mechanical Contractor Registration *************************************************************
					  	    
						    if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "Contractor Registration") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters15: " + rParams);
					
					  			generateReport(capId , "05 Mechanical Contractor Reg" , "Licenses", rParams);    
						  	
						    	}	
						    
						    
//***********************************  Mechanical Refrig Journeyman *************************************************************
					  	    
						    if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "RefrigJourneyman") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters16: " + rParams);
					
					  			generateReport(capId , "16 Refrigeration Journeyman" , "Licenses", rParams);    
						  	
						    	}
						    
						    
//***********************************  Building Sign-Awing Contractor *************************************************************
					  	    
						    if (appTypeArray[1] == "Building" && appTypeArray[2] == "Sign-AwingContractor") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters17: " + rParams);
					
					  			generateReport(capId , "03 Sign Contractor Reg" , "Licenses", rParams);    
						  	
						    	}	
						    
						    
//***********************************  Electrical Masters-Journeyman *************************************************************
					  	    
						    if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Masters-Journeyman") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters18: " + rParams);
					
					  			generateReport(capId , "03 Sign Contractor Reg" , "Licenses", rParams);    
						  	
						    	}	
						    
	
//*********************************** Elevator Contractor_Journey *************************************************************
					  	    
						    if (appTypeArray[1] == "Mechanical" && appTypeArray[2] == "Elevator") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters19: " + rParams);
					
					  			generateReport(capId , "15 Elevator Contractor_Journey" , "Licenses", rParams);    
						  	
						    	}
						    
	
//*********************************** Building Wrecking Contractor *************************************************************
					  	    
						    if (appTypeArray[1] == "Building" && appTypeArray[2] == "WreckingContractor") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters20: " + rParams);
					
					  			generateReport(capId , "04 Wrecking Contractor Reg" , "Licenses", rParams);    
						  	
						    	}				
	
						    
//*********************************** Electrical Masters-Journeyman *************************************************************
					  	    
						    if (appTypeArray[1] == "Electrical" && appTypeArray[2] == "Masters-Journeyman") {
						    		
						    	var rParams = aa.util.newHashMap();
								
						  		addParameter(rParams,"RECORD_ID",newLicIdString );
					  			addParameter(rParams,"TASK","License Issuance");
					  			addParameter(rParams,"ITEM_NAME","LIC LICENSED PROFESSIONALS");
					  			addParameter(rParams,"PRIMARY_","Y");
					  			
					  			logDebug("Parameters21: " + rParams);
					
					  			generateReport(capId , "10 Electrical Masters-Journeyman" , "Licenses", rParams);    
						  	
						    	}					
	
	}	    
						    
						    
						    
										 }catch (err) {
												logDebug("A JavaScript Error occured: " + err.message + " In Line " + err.lineNumber);
											}
										// end user code
											aa.env.setValue("ScriptReturnCode", "1"); 	aa.env.setValue("ScriptReturnMessage", debug)

