/**
 * This function sets theGlobal Flag
 * @returns
 * 
 * Formatted By:- Chaitanya Tanna, City of Detroit
 */

function GlobalFlags(){
	LICENSESTATE = "MI";
}
