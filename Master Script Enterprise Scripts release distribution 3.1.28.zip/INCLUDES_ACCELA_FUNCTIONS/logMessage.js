
function logMessage(dstr)
	{
	message+=dstr + br;
	}
